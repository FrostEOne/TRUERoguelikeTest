..
    A notice included as the header by a few sources.

.. note::
    These docs are incomplete.  Several functions and features are better
    documented by the older 1.6.4 docs `which you can find here
    <https://libtcod.github.io/docs/index2.html?c=true&cpp=true>`_.
